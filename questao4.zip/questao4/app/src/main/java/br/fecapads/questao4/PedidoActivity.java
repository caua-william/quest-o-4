package br.fecapads.questao4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class PedidoActivity extends AppCompatActivity {

    private RadioGroup rgLanche;
    private EditText edtNome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedido);

        rgLanche = findViewById(R.id.rgLanche);
        edtNome = findViewById(R.id.edtNome);
        Button btnConfirmarPedido = findViewById(R.id.btnConfirmarPedido);

        btnConfirmarPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = rgLanche.getCheckedRadioButtonId();
                RadioButton selectedLanche = findViewById(selectedId);
                String nome = edtNome.getText().toString();
                String lancheEscolhido = selectedLanche.getText().toString();

                Intent intent = new Intent(PedidoActivity.this, ResumoActivity.class);
                intent.putExtra("nome", nome);
                intent.putExtra("lanche", lancheEscolhido);
                startActivity(intent);
            }
        });
    }
}
