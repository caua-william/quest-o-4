package br.fecapads.questao4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResumoActivity extends AppCompatActivity {

    private TextView tvResumo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumo);

        tvResumo = findViewById(R.id.tvResumo);
        Button btnNovoPedido = findViewById(R.id.btnNovoPedido);

        String nome = getIntent().getStringExtra("nome");
        String lanche = getIntent().getStringExtra("lanche");

        tvResumo.setText("Nome: " + nome + "\nLanche Escolhido: " + lanche);

        btnNovoPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResumoActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}

